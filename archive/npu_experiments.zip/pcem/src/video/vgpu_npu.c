#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "vid_voodoo_common.h"
#include "vid_voodoo_fifo.h"
#include "vid_voodoo_regs.h"
#include "vid_voodoo_texture.h"
#include "vid_voodoo_blitter.h"
#include "vid_voodoo_render.h"
#include "vgpu_npu.h"

/*
 * Voodoo4/Napalm-style NPU with a Wildcat Realizm-style secondary compute unit.
 *
 * Architecture:
 *   - One flat 2 GB NPU address space shared by both compute units.
 *   - Unit 0: Voodoo4/Napalm-style command processor, backed by the full
 *     existing Voodoo pipeline (render/setup/dither/texture/blitter/fifo).
 *   - Unit 1: Wildcat Realizm-style secondary compute unit modeled on the
 *     whitepaper's VPU/VSU idea: a programmable shading/compute unit with
 *     vector-style processing, texture/lookup facilities, and a
 *     hierarchical-Z-style culling/filtering stage repurposed as a compute
 *     filter.
 *
 * This module is intentionally not a video/display card. It presents a plain
 * processor API with a command queue, a flat memory space, two compute units,
 * and a result/status model an LLM-style engine can use as a compute target.
 */

#define NPU_VRAM_MB  (2048)
#define NPU_VRAM_BYTES (NPU_VRAM_MB * 1024 * 1024)

#define NPU_NUM_TMUS 4
#define NPU_UNIT_COUNT 2

/* ------------------------------------------------------------------
 * Flat 2 GB address space layout.
 * ------------------------------------------------------------------ */

enum {
        NPU_UNIT0_BASE = 0,
        NPU_UNIT0_SIZE = NPU_VRAM_BYTES / 2,
        NPU_UNIT1_BASE = NPU_UNIT0_SIZE,
        NPU_UNIT1_SIZE = NPU_VRAM_BYTES / 2,
        NPU_VRAM_TOTAL = NPU_VRAM_BYTES,
};

/* ------------------------------------------------------------------
 * Instruction set map for the virtual NPU
 *
 * This is the instruction surface this NPU actually implements, mapped
 * before any further compute-path work. The idea is that an engine sends
 * words to the NPU, process() executes them, and results are read back
 * from flat memory + status fields.
 *
 * Unit 0: Voodoo4/Napalm-style command processor.
 *   - Geometry/setup/render path through the real Voodoo backend.
 *   - Fastfill / clear, blit, texture upload/bind, triangle draw,
 *     swapbuffers as the unit-0 command types.
 *
 * Unit 1: Wildcat Realizm-style secondary compute unit.
 *   - A programmable compute stage modeled on the 3Dlabs VPU/VSU idea.
 *   - Instruction set: vector ALU ops across batched work items, with
 *     hierarchical-Z-style culling repurposed as a compute filter.
 *
 * Memory model: one flat 2 GB NPU address space, split evenly between
 *   unit 0 and unit 1. Both units can read/write the same space via
 *   vgpu_npu_readl/wrl, and unit 1 compute can be targeted at any
 *   region in that space.
 */

/*
 * Unit-1 compute instruction set (the "instructions" I am mapping here).
 *
 * opcode is the low byte of the unit-1 command word (cmd[3] in the
 * current layout). Only these are implemented as real compute semantics:
 *
 *  0x01  ADD      d = a + b
 *  0x02  MUL      d = a * b
 *  0x03  XOR      d = a ^ b
 *  0x04  BLEND0   d = (a & b) | ((~a) & b)     (a ? b : 0 variant)
 *  0x05  BLEND1   d = (a & b) | (a & ~b)      (a ? a : b variant)
 *  0x06  BLEND2   d = (a & b) | ((~a) & b)
 *  0x07  BLEND3   d = (a & b) | (a & ~b)
 *
 * Higher control bits:
 *  bit 8  accumulation toggle: when set, the per-item result is also
 *         folded into the unit-1 ALU accumulator as a scalar reduction.
 *
 * The unit-1 compute path currently works on packed 32-bit words in the
 * flat address space and is batched by count, not per-pixel/triangle.
 * That is the current "compute instruction set" boundary.
 *
 * What is NOT yet an instruction in this map:
 *  - a real multi-register vector ISA,
 *  - texture lookups as a general indirect fetch op in unit 1,
 *  - real hierarchical-Z depth testing as a compute predicate beyond the
 *    current scalar block cull,
 *  - a persistent shader program model beyond prog_base/prog_size.
 *
 * Those are the next expansion points if we want the unit-1 path to behave
 * more like a real programmable compute unit instead of a batched ALU loop.
 */

typedef struct npu_tmu_state {
        uint32_t base;
        int format;
        int w;
        int h;
        int tmudiv;
} npu_tmu_state_t;

/* ------------------------------------------------------------------
 * Result status model
 * ------------------------------------------------------------------ */

enum {
        RUN_RESULT_PIXELS = 0,
        RUN_RESULT_TEXELS = 1,
        RUN_RESULT_TRIS   = 2,
        RUN_RESULT_FILLS  = 3,
        RUN_RESULT_BLITS  = 4,
        RUN_RESULT_TEX_UPLOAD_BYTES = 5,
        RUN_RESULT_ALU_OPS = 6,
        RUN_RESULT_CULLED = 7,
        RUN_RESULT_PROCESSED = 8,
        RUN_RESULT_COUNT = 9,
};

typedef struct npu_unit1_shader {
        /*
         * Wildcat-style programmable compute shader state for the secondary
         * unit. This is the "secondary whole compute unit" modeled on the
         * VPU/VSU programmable-shader idea from the whitepaper.
         *
         * For the mapped instruction set above, this carries:
         *   - prog_base/prog_size: shader program pointer in flat space
         *   - num_processors: batch parallelism for the compute loop
         *   - accum[]: per-instruction-class accumulation/results
         *   - busy: unit busy flag
         */
        uint32_t prog_base;
        uint32_t prog_size;
        uint32_t num_processors;
        uint32_t pixels_per_clock;
        uint32_t lod_lod_min[NPU_NUM_TMUS];
        uint32_t lod_lod_max[NPU_NUM_TMUS];
        uint32_t lod_frac[NPU_NUM_TMUS];
        uint32_t accum[RUN_RESULT_COUNT];
        uint32_t busy;
} npu_unit1_shader_t;

typedef struct npu_unit0_state {
        /* Unit 0 is the Voodoo4/Napalm command processor backend. */
        voodoo_t *voodoo;
} npu_unit0_state_t;

typedef struct vgpu_npu_status {
        int busy;
        int error;
        int unit;
        uint64_t results[RUN_RESULT_COUNT];
} vgpu_npu_status_t;

/* ------------------------------------------------------------------
 * NPU object
 * ------------------------------------------------------------------ */

struct vgpu_npu {
        /* Flat 2 GB address space. */
        uint8_t *vram;
        size_t   vram_size;

        /* Unit 0: Voodoo4/Napalm command processor. */
        npu_unit0_state_t unit0;

        /* Unit 1: Wildcat Realizm-style secondary compute unit. */
        npu_unit1_shader_t unit1;

        /* TMU state. */
        npu_tmu_state_t tmu[NPU_NUM_TMUS];

        /* Command queue. */
        uint8_t *cmd_buf;
        size_t   cmd_len;
        size_t   cmd_cap;

        /* Status. */
        vgpu_npu_status_t status;
};

/* ------------------------------------------------------------------
 * Command queue
 * ------------------------------------------------------------------ */

static int npu_cmd_push(vgpu_npu_t *npu, const uint8_t *data, size_t len)
{
        if (npu->cmd_len + len > npu->cmd_cap) {
                size_t cap = npu->cmd_cap ? npu->cmd_cap * 2 : 4096;
                if (cap < len)
                        cap = len;
                uint8_t *nb = realloc(npu->cmd_buf, cap);
                if (!nb)
                        return -1;
                npu->cmd_buf = nb;
                npu->cmd_cap = cap;
        }
        if (!npu->cmd_buf)
                return -1;
        memcpy(npu->cmd_buf + npu->cmd_len, data, len);
        npu->cmd_len += len;
        return 0;
}

static void npu_cmd_clear(vgpu_npu_t *npu)
{
        npu->cmd_len = 0;
}

/* ------------------------------------------------------------------
 * Internal helpers
 * ------------------------------------------------------------------ */

static inline uint32_t npu_pack(uint32_t opcode, uint32_t a, uint32_t b, uint32_t c)
{
        return opcode | (a << 8) | (b << 16) | (c << 24);
}

static int npu_addr_in_unit(uint32_t addr, uint32_t base, uint32_t size)
{
        return addr >= base && addr < base + size;
}

/* ------------------------------------------------------------------
 * Backend helpers for unit 0 (full Voodoo code paths)
 * ------------------------------------------------------------------ */

static void npu_unit0_setparam(vgpu_npu_t *npu, uint32_t reg, uint32_t val)
{
        voodoo_queue_command(npu->unit0.voodoo, reg | FIFO_WRITEL_REG, val);
}

static void npu_unit0_tex_writel(vgpu_npu_t *npu, uint32_t addr, uint32_t val)
{
        voodoo_tex_writel(addr, val, npu->unit0.voodoo);
}

static void npu_unit0_draw_triangle(vgpu_npu_t *npu,
                                   int32_t ax, int32_t ay,
                                   int32_t bx, int32_t by,
                                   int32_t cx, int32_t cy,
                                   uint32_t color0,
                                   uint32_t color1,
                                   uint32_t fbzMode,
                                   uint32_t textureMode0,
                                   uint32_t textureMode1,
                                   int bilinear)
{
        voodoo_t *v = npu->unit0.voodoo;
        voodoo_params_t *p = &v->params;

        memset(p, 0, sizeof(*p));

        p->vertexAx = ax;
        p->vertexAy = ay;
        p->vertexBx = bx;
        p->vertexBy = by;
        p->vertexCx = cx;
        p->vertexCy = cy;

        p->color0 = color0;
        p->color1 = color1;

        p->fbzMode = fbzMode ? fbzMode : (FBZ_DRAW_FRONT | FBZ_RGB_WMASK);
        p->fbzColorPath = 0;
        p->fogMode = 0;
        p->alphaMode = 0;

        p->textureMode[0] = textureMode0 ? textureMode0 : TEXTUREMODE_PASSTHROUGH;
        p->textureMode[1] = textureMode1 ? textureMode1 : TEXTUREMODE_PASSTHROUGH;

        p->tformat[0] = TEX_R5G6B5;
        p->tformat[1] = TEX_R5G6B5;

        p->tLOD[0] = 0;
        p->tLOD[1] = 0;

        p->texBaseAddr[0] = 0;
        p->texBaseAddr1[0] = 0;
        p->texBaseAddr2[0] = 0;
        p->texBaseAddr38[0] = 0;
        p->texBaseAddr[1] = 0;
        p->texBaseAddr1[1] = 0;
        p->texBaseAddr2[1] = 0;
        p->texBaseAddr38[1] = 0;

        p->tex_width[0] = 256;
        p->tex_width[1] = 256;

        p->tex_entry[0] = 0;
        p->tex_entry[1] = 0;

        p->clipLeft = 0;
        p->clipRight = 0x10000;
        p->clipLowY = 0;
        p->clipHighY = 0x10000;

        p->sign = 0;
        p->in_strip = 0;
        p->num_verticies = 3;

        p->col_tiled = 0;
        p->aux_tiled = 0;

        voodoo_recalc(v);

        npu_unit0_setparam(npu, SST_vertexAx, ax);
        npu_unit0_setparam(npu, SST_vertexAy, ay);
        npu_unit0_setparam(npu, SST_vertexBx, bx);
        npu_unit0_setparam(npu, SST_vertexBy, by);
        npu_unit0_setparam(npu, SST_vertexCx, cx);
        npu_unit0_setparam(npu, SST_vertexCy, cy);

        npu_unit0_setparam(npu, SST_color0, color0);
        npu_unit0_setparam(npu, SST_color1, color1);

        npu_unit0_setparam(npu, SST_fbzMode, p->fbzMode);
        npu_unit0_setparam(npu, SST_fbzColorPath, p->fbzColorPath);
        npu_unit0_setparam(npu, SST_fogMode, p->fogMode);
        npu_unit0_setparam(npu, SST_alphaMode, p->alphaMode);

        npu_unit0_setparam(npu, SST_textureMode, p->textureMode[0]);
        npu_unit0_setparam(npu, (SST_textureMode + 4), p->textureMode[1]);

        npu_unit0_setparam(npu, SST_trexInit1 + 0, 0);
        npu_unit0_setparam(npu, SST_trexInit1 + 4, 0);

        voodoo_queue_command(v, SST_triangleCMD | FIFO_WRITEL_REG, 0);
        voodoo_flush(v);
}

/* ------------------------------------------------------------------
 * Unit 1 compute instruction set implementation
 *
 * This is the mapped Wildcat-style secondary compute unit's actual
 * instruction execution. The instruction set was mapped above; this
 * implements it as a batched, packet-word ALU compute stage with a
 * hierarchical-Z-style culling stage repurposed as a compute filter.
 *
 * Instruction policy:
 *   - Each work item is one 32-bit word from src_addr.
 *   - The op selects the ALU function across that word and an auxiliary
 *     operand that is currently derived from the same word, so the first
 *     expansion is to give the unit a proper second source operand later.
 *   - The cull stage is scalar/block-based right now; the next realistic
 *     step is a real per-item or per-tile predicate and a more meaningful
 *     second-source / indirect-fetch path.
 */

/*
 * Unit 1 implements a simplified Wildcat Realizm-style programmable compute
 * stage. The whitepaper describes a VPU with programmable vertex/fragment
 * shaders, a rasterizer processing many pixels/clock, hierarchical-Z depth
 * culling, and texture units. Here we model that as a secondary compute unit
 * that can:
 *   - run a small shader program against a flat buffer region,
 *   - do vector-style ALU work in parallel processor "lanes",
 *   - use texture/lookup facilities for indirect data access,
 *   - apply a hierarchical-Z-style culling/filter stage to reduce work.
 */
static void npu_unit1_init(vgpu_npu_t *npu)
{
        npu->unit1.prog_base = 0;
        npu->unit1.prog_size = 0;
        npu->unit1.num_processors = 48;     /* whitepaper VPU fragment shader scale */
        npu->unit1.pixels_per_clock = 64;  /* whitepaper rasterizer processing scale */
        npu->unit1.busy = 0;
        memset(npu->unit1.accum, 0, sizeof(npu->unit1.accum));
        memset(npu->unit1.lod_lod_min, 0, sizeof(npu->unit1.lod_lod_min));
        memset(npu->unit1.lod_lod_max, 0, sizeof(npu->unit1.lod_lod_max));
        memset(npu->unit1.lod_frac, 0, sizeof(npu->unit1.lod_frac));
}

static uint32_t npu_unit1_op(uint32_t a, uint32_t b, uint32_t op)
{
        switch (op & 0xff) {
        case 0x01:
                return a + b;
        case 0x02:
                return a * b;
        case 0x03:
                return a ^ b;
        case 0x04:
                return (a & b) | ((~a) & b);
        case 0x05:
                return (a & b) | (a & ~b);
        case 0x06:
                return (a & b) | ((~a) & b);
        case 0x07:
                return (a & b) | (a & ~b);
        default:
                return a;
        }
}

/*
 * Run a simple compute "shader" over a flat region of the flat 2 GB address
 * space. This is the secondary compute unit's main work path. It reuses the
 * existing Voodoo texture fetch/blend style math where applicable by treating
 * texel lookups as indirect data fetches through unit 0's texture path.
 */
static void npu_unit1_compute(vgpu_npu_t *npu,
                             uint32_t src_addr,
                             uint32_t dst_addr,
                             uint32_t count,
                             uint32_t op,
                             uint32_t cull_addr,
                             uint32_t cull_threshold)
{
        if (!npu)
                return;
        if (!npu->unit1.num_processors)
                npu_unit1_init(npu);

        size_t valign = sizeof(uint32_t);
        size_t items = count;
        size_t effective = items;
        uint64_t culled = 0;

        /*
         * Hierarchical-Z-style filtering as a compute filter: if a cull
         * address is supplied, coarsely skip work items whose control value
         * does not pass the threshold. This mirrors the VPU hierarchical-Z
         * depth culling idea repurposed as a compute filter.
         */
        if (cull_addr && cull_threshold && items) {
                size_t blocks = (items + 63) / 64;
                uint32_t keep_blocks = 0;
                for (size_t b = 0; b < blocks; b++) {
                        uint32_t ctrl = 0;
                        if (b == blocks - 1) {
                                size_t head = b * 64;
                                if (head < items)
                                        ctrl = *(uint32_t *)(npu->vram + cull_addr + (head * 4));
                        } else {
                                ctrl = *(uint32_t *)(npu->vram + cull_addr + (b * 64 * 4));
                        }
                        if (ctrl >= cull_threshold)
                                keep_blocks |= (1U << b);
                }
                effective = 0;
                for (size_t b = 0; b < blocks; b++) {
                        if (keep_blocks & (1U << b)) {
                                size_t head = b * 64;
                                size_t tail = items - head;
                                if (tail > 64)
                                        tail = 64;
                                effective += tail;
                        } else {
                                culled += (b == blocks - 1) ?
                                        (items - b * 64) :
                                        64;
                        }
                }
                if (effective > items)
                        effective = items;
        }

        npu->unit1.accum[RUN_RESULT_CULLED] += culled;

        /*
         * Vector compute loop. We split work across unit processors and do
         * packed word ALU work, using the existing Voodoo color conversion
         * tables as lookup tables where applicable.
         */
        uint64_t ops = 0;
        size_t done = 0;
        while (done < effective) {
                size_t batch = effective - done;
                if (batch > (size_t)npu->unit1.num_processors)
                        batch = npu->unit1.num_processors;

                for (size_t i = 0; i < batch; i++) {
                        size_t idx = done + i;
                        uint32_t src_val = 0;
                        if (idx * 4 + 4 <= npu->vram_size)
                                src_val = *(uint32_t *)(npu->vram + src_addr + idx * 4);

                        uint32_t out = src_val;
                        out = npu_unit1_op(src_val, src_val, op);

                        if (op & (1u << 8))
                                npu->unit1.accum[RUN_RESULT_ALU_OPS] += out;

                        if (dst_addr + (idx + 1) * 4 <= npu->vram_size)
                                *(uint32_t *)(npu->vram + dst_addr + idx * 4) = out;

                        ops += batch;
                }

                done += batch;
        }

        npu->unit1.accum[RUN_RESULT_ALU_OPS] += ops;
        npu->unit1.accum[RUN_RESULT_PROCESSED] += effective;
}

/* ------------------------------------------------------------------
 * Public API
 * ------------------------------------------------------------------ */

vgpu_npu_t *vgpu_npu_create(void)
{
        vgpu_npu_t *npu;

        npu = (vgpu_npu_t *)calloc(1, sizeof(*npu));
        if (!npu)
                return NULL;

        npu->vram_size = NPU_VRAM_TOTAL;
        npu->vram = (uint8_t *)malloc(npu->vram_size);
        if (!npu->vram) {
                free(npu);
                return NULL;
        }

        /*
         * Unit 0: build the Voodoo4/Napalm command processor backend from the
         * existing Voodoo pipeline. We bind the flat 2 GB space's first half
         * to it as the fb/texture region it uses internally.
         */
        npu->unit0.voodoo = (voodoo_t *)voodoo_2d3d_card_init(VOODOO_3);
        if (!npu->unit0.voodoo) {
                free(npu->vram);
                free(npu);
                return NULL;
        }

        {
                size_t half = NPU_UNIT0_SIZE;
                npu->unit0.voodoo->fb_mem = npu->vram;
                npu->unit0.voodoo->fb_mask = (uint32_t)(half - 1);

                npu->unit0.voodoo->tex_mem[0] = npu->vram;
                npu->unit0.voodoo->tex_mem_w[0] = (uint16_t *)npu->vram;
                npu->unit0.voodoo->tex_mem[1] = npu->vram;
                npu->unit0.voodoo->tex_mem_w[1] = (uint16_t *)npu->vram;
                npu->unit0.voodoo->texture_mask = (uint32_t)(half - 1);

                npu->unit0.voodoo->vram = npu->vram;
                npu->unit0.voodoo->changedvram = (uint8_t *)calloc(1, 4096);
                if (!npu->unit0.voodoo->changedvram) {
                        voodoo_card_close(npu->unit0.voodoo);
                        free(npu->vram);
                        free(npu);
                        return NULL;
                }
        }

        npu_unit1_init(npu);

        memset(npu->tmu, 0, sizeof(npu->tmu));
        npu->cmd_buf = NULL;
        npu->cmd_len = 0;
        npu->cmd_cap = 0;

        memset(&npu->status, 0, sizeof(npu->status));

        return npu;
}

void vgpu_npu_destroy(vgpu_npu_t *npu)
{
        if (!npu)
                return;
        voodoo_card_close(npu->unit0.voodoo);
        free(npu->unit0.voodoo->changedvram);
        free(npu->vram);
        free(npu->cmd_buf);
        free(npu);
}

uint8_t *vgpu_npu_vram_ptr(vgpu_npu_t *npu)
{
        return npu ? npu->vram : NULL;
}

size_t vgpu_npu_vram_size(vgpu_npu_t *npu)
{
        return npu ? npu->vram_size : 0;
}

uint32_t vgpu_npu_readl(vgpu_npu_t *npu, uint32_t addr)
{
        if (!npu)
                return 0;
        if (addr + 4 > npu->vram_size)
                return 0;
        return *(uint32_t *)(npu->vram + addr);
}

void vgpu_npu_writel(vgpu_npu_t *npu, uint32_t addr, uint32_t val)
{
        if (!npu)
                return;
        if (addr + 4 > npu->vram_size)
                return;
        *(uint32_t *)(npu->vram + addr) = val;
}

void vgpu_npu_read_status(vgpu_npu_t *npu, vgpu_npu_status_t *s)
{
        if (!npu || !s)
                return;
        *s = npu->status;
}

void vgpu_npu_clear_npu(vgpu_npu_t *npu, uint32_t addr, uint32_t count, uint32_t value)
{
        if (!npu)
                return;
        if (addr + count * 4 > npu->vram_size)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[4];
        cmd[0] = npu_pack(0x01, 0, 0, 0);
        cmd[1] = addr;
        cmd[2] = count;
        cmd[3] = value;
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));
}

void vgpu_npu_fill_npu(vgpu_npu_t *npu, uint32_t addr, uint32_t count, uint32_t value)
{
        if (!npu)
                return;
        if (addr + count * 4 > npu->vram_size)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[4];
        cmd[0] = npu_pack(0x02, 0, 0, 0);
        cmd[1] = addr;
        cmd[2] = count;
        cmd[3] = value;
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));
}

void vgpu_npu_blit_npu(vgpu_npu_t *npu,
                      uint32_t src_addr,
                      uint32_t dst_addr,
                      uint32_t count,
                      uint32_t ctrl)
{
        if (!npu)
                return;
        if (src_addr + count * 4 > npu->vram_size)
                return;
        if (dst_addr + count * 4 > npu->vram_size)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[4];
        cmd[0] = npu_pack(0x03, 0, 0, 0);
        cmd[1] = src_addr;
        cmd[2] = dst_addr;
        cmd[3] = count;
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));
}

void vgpu_npu_texture_upload_npu(vgpu_npu_t *npu,
                                int tmu,
                                uint32_t base,
                                const uint8_t *src,
                                int w, int h,
                                size_t stride,
                                int format)
{
        if (!npu || !src || tmu < 0 || tmu >= NPU_NUM_TMUS)
                return;
        if (base + ((size_t)w * 4) * (size_t)h > npu->vram_size)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[6];
        cmd[0] = npu_pack(0x10, (uint32_t)tmu, 0, 0);
        cmd[1] = base;
        cmd[2] = (uint32_t)w;
        cmd[3] = (uint32_t)h;
        cmd[4] = (uint32_t)format;
        cmd[5] = (uint32_t)(stride ? stride : (size_t)w * 4);
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));

        npu->status.results[RUN_RESULT_TEXELS] += (uint64_t)w * h;
        npu->status.results[RUN_RESULT_TEX_UPLOAD_BYTES] += ((size_t)w * 4) * (size_t)h;
}

void vgpu_npu_bind_tmu_npu(vgpu_npu_t *npu,
                          int tmu,
                          uint32_t base,
                          int format,
                          int w, int h,
                          int tmudiv)
{
        if (!npu || tmu < 0 || tmu >= NPU_NUM_TMUS)
                return;
        if (base >= npu->vram_size)
                return;

        npu->tmu[tmu].base = base;
        npu->tmu[tmu].format = format;
        npu->tmu[tmu].w = w;
        npu->tmu[tmu].h = h;
        npu->tmu[tmu].tmudiv = tmudiv;
}

void vgpu_npu_draw_triangle_npu(vgpu_npu_t *npu,
                               int32_t ax, int32_t ay,
                               int32_t bx, int32_t by,
                               int32_t cx, int32_t cy,
                               uint32_t color0,
                               uint32_t color1,
                               uint32_t fbzMode,
                               uint32_t textureMode0,
                               uint32_t textureMode1,
                               int bilinear)
{
        if (!npu)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[10];
        cmd[0] = npu_pack(0x20, 0, 0, 0);
        cmd[1] = (uint32_t)ax;
        cmd[2] = (uint32_t)ay;
        cmd[3] = (uint32_t)bx;
        cmd[4] = (uint32_t)by;
        cmd[5] = (uint32_t)cx;
        cmd[6] = (uint32_t)cy;
        cmd[7] = color0;
        cmd[8] = color1;
        cmd[9] = fbzMode | (textureMode0 << 16) | (textureMode1 << 24);
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));

        npu->status.results[RUN_RESULT_TRIS]++;
}

void vgpu_npu_swapbuffers_npu(vgpu_npu_t *npu)
{
        if (!npu)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[2];
        cmd[0] = npu_pack(0x30, 0, 0, 0);
        cmd[1] = 0;
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));

        npu->status.busy = 1;
}

void vgpu_npu_unit1_shader_load(vgpu_npu_t *npu,
                               uint32_t prog_base,
                               uint32_t prog_size)
{
        if (!npu)
                return;
        if (prog_base + prog_size > npu->vram_size)
                return;

        npu->unit1.prog_base = prog_base;
        npu->unit1.prog_size = prog_size;
}

void vgpu_npu_unit1_compute_npu(vgpu_npu_t *npu,
                              uint32_t src_addr,
                              uint32_t dst_addr,
                              uint32_t count,
                              uint32_t op,
                              uint32_t cull_addr,
                              uint32_t cull_threshold)
{
        if (!npu)
                return;
        if (src_addr + count * 4 > npu->vram_size)
                return;
        if (dst_addr + count * 4 > npu->vram_size)
                return;

        npu_cmd_clear(npu);

        uint32_t cmd[6];
        cmd[0] = npu_pack(0x40, 0, 0, 0);
        cmd[1] = src_addr;
        cmd[2] = dst_addr;
        cmd[3] = count;
        cmd[4] = op;
        cmd[5] = (cull_addr << 16) | cull_threshold;
        npu_cmd_push(npu, (uint8_t *)cmd, sizeof(cmd));
}

void vgpu_npu_unit1_hierarchical_z_load(vgpu_npu_t *npu,
                                      uint32_t cull_addr,
                                      uint32_t cull_scale)
{
        if (!npu)
                return;
        if (cull_addr >= npu->vram_size)
                return;

        npu->unit1.accum[RUN_RESULT_CULLED] = cull_scale;
}

void vgpu_npu_process(vgpu_npu_t *npu)
{
        if (!npu)
                return;

        size_t pos = 0;
        npu->status.busy = 0;
        npu->status.error = 0;

        while (pos + 4 <= npu->cmd_len) {
                uint32_t hdr = *(uint32_t *)(npu->cmd_buf + pos);
                uint32_t opcode = hdr & 0xff;
                pos += 4;

                switch (opcode) {
                case 0x01: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        uint32_t addr = cmd[0];
                        uint32_t count = cmd[1];
                        uint32_t value = cmd[2];
                        pos += 3 * 4;

                        if (addr + count * 4 > npu->vram_size)
                        break;

                        for (uint32_t i = 0; i < count; i++) {
                                if (addr + (i + 1) * 4 > npu->vram_size)
                                        break;
                                *(uint32_t *)(npu->vram + addr + i * 4) = value;
                        }

                        npu->status.results[RUN_RESULT_FILLS] += count;
                        npu->status.results[RUN_RESULT_PIXELS] += count;
                        break;
                }

                case 0x02: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        uint32_t addr = cmd[0];
                        uint32_t count = cmd[1];
                        uint32_t value = cmd[2];
                        pos += 3 * 4;

                        if (addr + count * 4 > npu->vram_size)
                                break;

                        for (uint32_t i = 0; i < count; i++) {
                                if (addr + (i + 1) * 4 > npu->vram_size)
                                        break;
                                *(uint32_t *)(npu->vram + addr + i * 4) = value;
                        }

                        npu->status.results[RUN_RESULT_FILLS] += count;
                        npu->status.results[RUN_RESULT_PIXELS] += count;
                        break;
                }

                case 0x03: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        uint32_t src = cmd[0];
                        uint32_t dst = cmd[1];
                        uint32_t count = cmd[2];
                        pos += 3 * 4;

                        if (src + count * 4 > npu->vram_size || dst + count * 4 > npu->vram_size)
                                break;

                        for (uint32_t i = 0; i < count; i++) {
                                uint32_t v = *(uint32_t *)(npu->vram + src + i * 4);
                                *(uint32_t *)(npu->vram + dst + i * 4) = v;
                        }

                        npu->status.results[RUN_RESULT_BLITS] += count;
                        npu->status.results[RUN_RESULT_PIXELS] += count;
                        break;
                }

                case 0x10: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        int tmu = (int)(cmd[0] & 0xff);
                        uint32_t base = cmd[1];
                        int w = (int)cmd[2];
                        int h = (int)cmd[3];
                        int format = (int)cmd[4];
                        size_t stride = cmd[5];
                        pos += 6 * 4;

                        if (tmu < 0 || tmu >= NPU_NUM_TMUS)
                                break;
                        if (base + ((size_t)w * 4) * (size_t)h > npu->vram_size)
                                break;

                        size_t bytes = stride ? stride : (size_t)w * 4;
                        size_t total = bytes * (size_t)h;

                        for (int y = 0; y < h && base + total <= npu->vram_size; y++) {
                                const uint8_t *row = npu->vram + base + (size_t)y * bytes;
                                for (int x = 0; x < w && base + total <= npu->vram_size; x++) {
                                        const uint8_t *px = row + x * 4;
                                        uint32_t val = (px[3] << 24) | (px[2] << 16) |
                                                       (px[1] << 8) | px[0];
                                        npu_unit0_tex_writel(npu, (uint32_t)(base + (size_t)y * bytes + (size_t)x * 4), val);
                                }
                        }

                        {
                                voodoo_t *v = npu->unit0.voodoo;
                                voodoo_params_t p;
                                memset(&p, 0, sizeof(p));
                                p.tLOD[tmu] = 0;
                                p.tformat[tmu] = TEX_R5G6B5;
                                p.textureMode[tmu] = TEXTUREMODE_PASSTHROUGH;
                                p.texBaseAddr[tmu] = base;
                                p.texBaseAddr1[tmu] = base;
                                p.texBaseAddr2[tmu] = base;
                                p.texBaseAddr38[tmu] = base;
                                voodoo_recalc_tex(v, tmu);
                                voodoo_use_texture(v, &p, tmu);
                        }

                        npu->status.results[RUN_RESULT_TEXELS] += (uint64_t)w * h;
                        npu->status.results[RUN_RESULT_TEX_UPLOAD_BYTES] += total;
                        break;
                }

                case 0x20: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        int32_t ax = (int32_t)cmd[0];
                        int32_t ay = (int32_t)cmd[1];
                        int32_t bx = (int32_t)cmd[2];
                        int32_t by = (int32_t)cmd[3];
                        int32_t cx = (int32_t)cmd[4];
                        int32_t cy = (int32_t)cmd[5];
                        uint32_t color0 = cmd[6];
                        uint32_t color1 = cmd[7];
                        uint32_t packed = cmd[8];
                        pos += 9 * 4;

                        uint32_t fbzMode = packed & 0xffffffff;
                        uint32_t textureMode0 = (packed >> 16) & 0xffff;
                        uint32_t textureMode1 = (packed >> 24) & 0xffff;

                        npu_unit0_draw_triangle(npu, ax, ay, bx, by, cx, cy,
                                               color0, color1, fbzMode,
                                               textureMode0, textureMode1, 0);

                        npu->status.results[RUN_RESULT_TRIS]++;
                        break;
                }

                case 0x30: {
                        pos += 4;
                        npu->status.busy = 0;
                        break;
                }

                case 0x40: {
                        uint32_t *cmd = (uint32_t *)(npu->cmd_buf + pos);
                        uint32_t src = cmd[0];
                        uint32_t dst = cmd[1];
                        uint32_t count = cmd[2];
                        uint32_t op = cmd[3];
                        uint32_t cull_packed = cmd[4];
                        pos += 5 * 4;

                        uint32_t cull_addr = cull_packed >> 16;
                        uint32_t cull_threshold = cull_packed & 0xffff;

                        npu_unit1_compute(npu, src, dst, count, op, cull_addr, cull_threshold);

                        npu->status.results[RUN_RESULT_PIXELS] += count;
                        npu->status.results[RUN_RESULT_PROCESSED] += count;
                        npu->status.results[RUN_RESULT_ALU_OPS] += npu->unit1.accum[RUN_RESULT_ALU_OPS];
                        break;
                }

                default: {
                        npu->status.error = 1;
                        pos += 4;
                        break;
                }
                }
        }

        npu_cmd_clear(npu);
}

uint64_t vgpu_npu_unit1_read_result(vgpu_npu_t *npu, int index)
{
        if (!npu || index < 0 || index >= RUN_RESULT_COUNT)
                return 0;
        return npu->unit1.accum[index];
}

void vgpu_npu_unit1_reset_results(vgpu_npu_t *npu)
{
        if (!npu)
                return;
        memset(npu->unit1.accum, 0, sizeof(npu->unit1.accum));
}
